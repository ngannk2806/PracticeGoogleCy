var ClientREST = require('node-rest-client').Client;

module.exports = class BaseAPI {

    constructor(delayTime = 60) {
    };

    sleep(s) {
        return new Promise(resolve => {
            setTimeout(resolve, s * 1000);
        });
    };

    async postInnoDataFeedHub() {
        console.log("calling postInnoDataFeedHub....")
        var clientRest = new ClientREST();
        // set content-type header and data as json in args parameter
        var args = {
            data: { test: "hello" },
            headers: { "Content-Type": "application/json" }
        };
        var req = await clientRest.post('https://streaming-core-uat.hsc.com.vn/InnoDataFeedHub/negotiate?negotiateVersion=1', args, function (data, response) {
            // raw response
            console.log(`postInnoDataFeedHub log: ` + response);
        });

        req.on('requestTimeout', function (req) {
            console.log('request has expired');
            req.abort();
        });

        req.on('responseTimeout', function (res) {
            console.log('response has expired');

        });

        //it's usefull to handle request errors to avoid, for example, socket hang up errors on request timeouts
        req.on('error', function (err) {
            console.log('request error', err);
        });
    }
}