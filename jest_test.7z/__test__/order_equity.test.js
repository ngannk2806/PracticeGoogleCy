const pt = require('puppeteer');
const TEST_DATA_FILE = require('../fixtures/trading/data-test/tfe_equity_hnx.json');
const it = require('jest-retries');
const Equity = require('./order_equity');
const utils = require('./utils');

jest.setTimeout(120 * 1000);


describe('HSC Trading', () => {

    var equity = new Equity();
    const utilsObject = new utils();

    beforeAll(async () => {
        const url = await equity.launchBrowser();
        const title = await equity.getTitle();
        await expect(url).toContain('/login');
        await expect(title).toEqual('myhsc - Dịch vụ');
        const homeUrl = await equity.login(TEST_DATA_FILE.userName, TEST_DATA_FILE.password);
        await expect(homeUrl).toContain('/FO_TF_SQ');
        await equity.clickEquityButton();
    });

    afterAll(async () => {
        await equity.clickCloseBtnIfAny();

        await equity.logOut();
        await equity.closeBrowser();
    });

    beforeEach(async () => {
        await equity.reLoginIfAnyAndGoToEquity();
        const curUrl = await equity.getCurrentUrl();
        await expect(curUrl).toContain('/Equity');
    });

    afterEach(async () => {
        await equity.clickConfirmButtonIfAny();
    });

    TEST_DATA_FILE.stockCodes.forEach((code, index, lists) => {
        if (index >= 0) {
            it(`search ${code} then freeze browser`, async () => {
                const actualCode = await equity.searchStockCode(code);
                await expect(actualCode).toMatch(code);
                await equity.setPageIntercept();
            });

            it(`with ${code} then check colors`, async () => {
                var pricesToCheck = [];
                
                const floorCeilRefer = await equity.getFloorCeilRefer();
                pricesToCheck = pricesToCheck.concat(await equity.getInnoChangeValues());
                const [priceValues, buySellValues] = await equity.getPriceVolumnes();
                pricesToCheck = pricesToCheck.concat(await priceValues);
                pricesToCheck = pricesToCheck.concat(await equity.getOpenHighestLowestAvgPrices());
                // console.log(`pricesToCheck: ${pricesToCheck.join("\n")}`);


                const priceHeaders = ["Giá khớp", "Thay đổi giá", "% thay đổi giá", "Giá bán 1", "Giá bán 2", "Giá bán 3", "Giá mua 1", "Giá mua 2", "Giá mua 3",
                    "Giá mở cửa", "Giá cao nhất", "Giá thấp nhất", "Giá trung bình"]
                const buySellHeaders = ["KL mua 1", "KL mua 2", "KL mua 3", "KL bán 1", "KL bán 2", "KL bán 3"]
                const failListFloorCeilRefer = await equity.checkFloorCeilRefeColors(floorCeilRefer[0], floorCeilRefer[1], floorCeilRefer[2]);
                const failListBuySell = await equity.checkBuySellNumbersColors(buySellHeaders, buySellValues);
                const failListPrices = await equity.checkPricesColors(floorCeilRefer[0], floorCeilRefer[1], floorCeilRefer[2], priceHeaders, pricesToCheck);
                const failSameColorLastDeviationPercent = await equity.checkLatestDevPercent(pricesToCheck[0], pricesToCheck[1], pricesToCheck[2]);
                if (failListPrices.length > 0 || failListBuySell.length > 0 || failListFloorCeilRefer.length > 0 || failSameColorLastDeviationPercent.length > 0) {
                    await equity.page.screenshot({ path: `logs/equity_order_${code}.png` });
                }
                await utilsObject.writeFailCheckColorToFile(code, floorCeilRefer,
                                                            failListFloorCeilRefer, failListBuySell, failListPrices, failSameColorLastDeviationPercent,
                                                            buySellValues, buySellHeaders, pricesToCheck, priceHeaders,
                                                            'equity_order_');


                //assertion
                await expect(failListFloorCeilRefer.length).toBe(0);
                await expect(failListBuySell.length).toBe(0);
                await expect(failListPrices.length).toBe(0);
                await equity.removePageIntercept();
            });

            it(`with ${code} then check number row of trade log`, async () => {
                await equity.scrollToLastRowOfTradeLog();
                var numberRowOfTradeLog = await equity.getNumberRowOfTradeLog();
                await expect(numberRowOfTradeLog).toBeLessThanOrEqual(50);
            });

            it(`with ${code} then check color of trade log`, async () => {
                var priceFailList = await equity.checkPriceColorOfTradeLog();
                var typeFailList = await equity.checkTypeTradeColorOfTradeLog();

                await expect(priceFailList.length).toBe(0);
                await expect(typeFailList.length).toBe(0)

                if (priceFailList.length > 0) {
                    await utilsObject.writeFailListToFile(code, priceFailList, 'equity_order_');
                }
                if (typeFailList.length > 0) {
                    await utilsObject.writeFailListToFile(code, typeFailList, 'equity_order_')
                }
            });

            it(`with ${code} then stop freeze browser`, async () => {
                await equity.removePageIntercept();
            });
        };
    });
});
