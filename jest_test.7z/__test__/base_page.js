const pt = require('puppeteer');
const Utils = require('./utils');


module.exports = class BasePage {
    constructor(delayTime = 60) {
        this.browser = null;
        this.page = null;
        this.delayTime = delayTime;
        this.LOG_IN_LOG_OUT_FIXTURES = require('../fixtures/trading/locators/login_page_uat.json')
        this.BASE_PAGE_FIXTURES = require('../fixtures/trading/locators/base_page.json')
        this.utilsObject = new Utils();
    };

    sleep(s) {
        return new Promise(resolve => {
            setTimeout(resolve, s * 1000);
        });
    };


    async launchBrowser() {
        console.log("Launch browser");
        this.browser = await pt.launch({ headless: false, args: ['--start-maximized'] });
        this.page = await this.browser.newPage();


        await this.page.setViewport({ width: 1920, height: 1060 });
        await this.page.goto(this.LOG_IN_LOG_OUT_FIXTURES.url);
        await this.page.waitForNetworkIdle();
        await this.sleep(2);

        await this.page.screenshot({ path: 'logs/hsc.png' });
        return this.page.url();
    };

    async getTitle() {
        return await this.page.title();
    };

    async getTextWidth() {
        var ele = document.createElement('canvas');
        ele.getContext().font()
    }

    async clickCloseBtnIfAny() {
        await this.page.$x('//button[@title="Đóng"]').then((closeBtn) => {
            if (closeBtn.length > 0) {
                closeBtn[0].click({ delay: this.delayTime });
            }
        })
    };

    async logOut() {
        const logoutIcon = await this.page.$x(this.LOG_IN_LOG_OUT_FIXTURES.logoutIcon);
        if (logoutIcon.length > 0) {
            await logoutIcon[0].click({ delay: this.delayTime });
            await this.sleep(1);
            await this.page.evaluate(function (logoutText) {
                Array.from(document.querySelectorAll('li')).filter(li => {
                    return li.innerText == logoutText;
                }).forEach(element => {
                    if (element) element.click();
                });
            }, this.LOG_IN_LOG_OUT_FIXTURES.logoutText);
            await this.sleep(1);
        }
    };

    async closeBrowser() {
        await this.browser.close();
    };

    async login(username, pwd) {
        console.log(`Login with ${username} / ${pwd}`);

        const iframeElement = await this.page.waitForSelector(this.LOG_IN_LOG_OUT_FIXTURES.iframe);
        const iframe = await iframeElement.contentFrame();

        const usernameEle = await iframe.$(this.LOG_IN_LOG_OUT_FIXTURES.username);
        await usernameEle.click({ clickCount: 2 });
        await usernameEle.type(username, { delay: this.delayTime });

        const passwordEle = await iframe.$(this.LOG_IN_LOG_OUT_FIXTURES.password);
        await passwordEle.click({ clickCount: 2 });
        await passwordEle.type(pwd, { delay: this.delayTime });

        const loginBtn = await iframe.$x(this.LOG_IN_LOG_OUT_FIXTURES.loginBtn);
        await loginBtn[0].click();
        await this.page.waitForNetworkIdle();
        await this.sleep(20);

        await this.page.screenshot({ path: 'logs/login.png' });
        await this.page.waitForNetworkIdle();
        const curUrl = await this.page.url();
        return curUrl;
    };

    async reLoginIfAnyAndGoToEquity(username, pwd) {
        const curUrl = await this.page.url();
        if (curUrl.includes('/login')) {
            await this.login(username, pwd);
            await this.clickEquityButton();
        }
        return await this.page.url();
    }

    async getCurrentUrl() {
        return await this.page.url();
    }

    async setPageIntercept() {
        await this.page.setRequestInterception(true);
        this.page.on('request', interceptedRequest => {
            if (interceptedRequest.url().includes(this.BASE_PAGE_FIXTURES.streamingUrl))
                interceptedRequest.abort();
            else
                interceptedRequest.continue();
        });

    };

    async requestAPI() {
        console.log('requestAPI ...........')
        var TARGET_URL = 'https://streaming-core-uat.hsc.com.vn/InnoDataFeedHub/negotiate?negotiateVersion=1';
        await this.page.setRequestInterception(true);



        var res = this.page.once('request', request => {
            request.continue({method: 'POST', postData: JSON.stringify('{}'), headers: request.headers});
            return request.response().json();
        });
        
        await this.page.goto(TARGET_URL);

        await this.page.setRequestInterception(false);
    }

    async removePageIntercept() {
        await this.page.setRequestInterception(false);
    }

    async selectOneStockView() {
        await this.selectStockView(this.BASE_PAGE_FIXTURES.oneStockView);
    };

    async selectTwoStockView() {
        await this.selectStockView(this.BASE_PAGE_FIXTURES.twoStockView);
    };



    async selectStockView(typeStockView) {
        var stockViewDropDownItem = this.BASE_PAGE_FIXTURES.stockViewDropDownItemX.replace('%s', typeStockView);

        var currentStockView = await this.utilsObject.getTextOfElement(this.page, this.BASE_PAGE_FIXTURES.stockViewBtn)
        if (currentStockView != typeStockView) {
            await this.utilsObject.clickToElement(this.page, this.BASE_PAGE_FIXTURES.stockViewBtn);
            await this.sleep(1);
            await this.utilsObject.clickToElement(this.page, stockViewDropDownItem);
            await this.page.reload();
        };
    };

    async clickCloseBtnIfAny() {
        await this.page.$x('//button[@title="Đóng"]').then((closeBtn) => {
            if (closeBtn.length > 0) {
                closeBtn[0].click({ delay: this.delayTime });
            }
        })
    };

    async clickConfirmButtonIfAny() {
        const confirmBtn = await this.page.$x(this.BASE_PAGE_FIXTURES.confirmBtn);
        if (confirmBtn.length > 0) {
            await confirmBtn[0].click();
            await this.sleep(2);
        }
    };

    async getExpectedColor(floorValue, ceilValue, referValue, sValue) {
        var expectedColor;
        if (sValue != "-") {
            let fValue = parseFloat(sValue);
            if (sValue.includes('+')) {
                expectedColor = this.BASE_PAGE_FIXTURES.greenColor;
            }
            else if (sValue.includes('-')) {
                expectedColor = this.BASE_PAGE_FIXTURES.redColor;
            }
            else if ((sValue == 'ATO') || (sValue == 'ATC')) {
                expectedColor = this.BASE_PAGE_FIXTURES.whiteColor;
            } else if (fValue == floorValue) {
                expectedColor = this.BASE_PAGE_FIXTURES.cyanColor;
            } else if ((fValue > floorValue) && (fValue < referValue)) {
                expectedColor = this.BASE_PAGE_FIXTURES.redColor;
            } else if (fValue == referValue) {
                expectedColor = this.BASE_PAGE_FIXTURES.yellowColor;
            } else if ((fValue > referValue) && (fValue < ceilValue)) {
                expectedColor = this.BASE_PAGE_FIXTURES.greenColor;
            } else if (fValue == ceilValue) {
                expectedColor = this.BASE_PAGE_FIXTURES.violetColor;
            } else if (fValue == 0) {
                expectedColor = this.BASE_PAGE_FIXTURES.yellowColor;
            }
            else {
                expectedColor = `NOT FOUND suitable color for ${sValue}`
            }
        } else {
            expectedColor = this.BASE_PAGE_FIXTURES.yellowColor;
        }
        return expectedColor;
    }

    async checkLatestDevPercent(latestPrice, deviation, percent) {
        let failList = [];
        let latestPriceColor = latestPrice[1];
        let deviationColor = deviation[1];
        let percentColor = percent[1];
        if (latestPriceColor != deviationColor
            || deviationColor != percentColor
            || deviationColor != percentColor) {
            failList.push(`latestPrice: ${latestPrice} - deviationValue: ${deviation} - percentValue: ${percent}`);
        }
        return failList;
    }

    async checkPricesColors(floor, ceil, refer, headers, curDatas) {
        let floorValue = parseFloat(floor[0]);
        let referValue = parseFloat(refer[0]);
        let ceilValue = parseFloat(ceil[0]);

        let failList = [];
        for (let i = 0; i < curDatas.length; i++) {
            let curColor = curDatas[i][1];
            let expectedColor = await this.getExpectedColor(floorValue, ceilValue, referValue, curDatas[i][0]);
            if (curColor != expectedColor) {
                failList.push(`floor: ${floorValue} - refer: ${referValue} - ceil: ${ceilValue} - cur: ${curDatas[i][0]} (${curDatas[i]}).\nColor of ${headers[i]} should be ${expectedColor}. Actual color is ${curColor}`);
            }
        }
        return failList;
    }

    async checkFloorCeilRefeColors(floor, ceil, refer) {
        let failList = [];
        if (ceil[1] != this.BASE_PAGE_FIXTURES.violetColor) {
            failList.push(`Ceil's color is wrong. Expected: ${this.BASE_PAGE_FIXTURES.violetColor}, actual: ${ceil[1]}`);
        }
        if (refer[1] != this.BASE_PAGE_FIXTURES.yellowColor) {
            failList.push(`Refer's color is wrong. Expected: ${this.BASE_PAGE_FIXTURES.yellowColor}, actual: ${refer[1]}`);
        }
        if (floor[1] != this.BASE_PAGE_FIXTURES.cyanColor) {
            failList.push(`Floor's color is wrong. Expected: ${this.BASE_PAGE_FIXTURES.cyanColor}, actual: ${floor[1]}`);
        }
        return failList;

    }

    async selectFavouriteItem(favouriteItem) {
        let favouriteDropDown = this.BASE_PAGE_FIXTURES.favouriteItemName.replace('%favouriteName', favouriteItem);
        let currentItem = await this.utilsObject.getTextOfElement(this.page, this.BASE_PAGE_FIXTURES.favouriteStockBtn);

        if (currentItem != favouriteItem) {
            await this.utilsObject.clickToElement(this.page, this.BASE_PAGE_FIXTURES.favouriteStockBtn);
            await this.sleep(1);
            await this.utilsObject.clickToElement(this.page, favouriteDropDown);
            await this.sleep(1);
        }
    }



    async checkBuySellNumbersColors(headers, values) {
        let failList = [];
        //check buy
        for (let i = 0; i < 3; i++) {
            if (values[i][1] != this.BASE_PAGE_FIXTURES.whiteColor) {
                failList.push(`${headers[i]} ${values[i][0]} is wrong text color. Expected: ${this.BASE_PAGE_FIXTURES.whiteColor}, actual: ${values[i][1]}`);
            }
            // if (bgColors[i] != greenColor) {
            //     failList.push(`${headers[i]} ${values[i]} is wrong background color. Expected: ${greenColor}, actual: ${bgColors[i]}`)
            // }
        }
        //check sell
        for (let i = 3; i < values.length; i++) {
            if (values[i][1] != this.BASE_PAGE_FIXTURES.whiteColor) {
                failList.push(`${headers[i]} ${values[i][0]} is wrong text color. Expected: ${this.BASE_PAGE_FIXTURES.whiteColor}, actual: ${values[i][1]}`);
            }
            // if (bgColors[i] != redColor) {
            //     failList.push(`${headers[i]} ${values[i]} is wrong background color. Expected: ${redColor}, actual: ${bgColors[i]}`)
            // }
        }
        return failList;

    }
}