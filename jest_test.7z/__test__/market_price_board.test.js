var pt = require('puppeteer');
var TEST_DATA_FILE = require('../fixtures/trading/data-test/tfe_equity_market_price_board.json');
var it = require('jest-retries');
var EquityMarket = require('./market_equity');
var utils = require('./utils');

jest.setTimeout(120 * 1000);

describe('Checking Price Board', () => {


    var equity = new EquityMarket();
    var utilsObject = new utils();


    beforeAll(async () => {
        var url = await equity.launchBrowser();
        var title = await equity.getTitle();
        await expect(url).toContain('/login');
        await expect(title).toEqual('myhsc - Dịch vụ');
        var homeUrl = await equity.login(TEST_DATA_FILE.userName, TEST_DATA_FILE.password);
        await equity.gotoEquityMarket();
    });

    afterAll(async () => {
        await equity.clickCloseBtnIfAny();

        await equity.logOut();
        await equity.closeBrowser();
    });

    beforeEach(async () => {
        await equity.reLoginIfAnyAndGoToEquity();
    });

    afterEach(async () => {
        await equity.clickConfirmButtonIfAny();
    });


    TEST_DATA_FILE.equityFavouriteList.forEach((favouriteItem, idx, lists) => {
        it(`Equity Market - select ${favouriteItem} at stock favourite list`, async () => {

            await equity.gotoEquityMarket();

            await equity.selectOneStockView();
            await equity.selectFavouriteItem(favouriteItem);
            await equity.sleep(1);


            var size = await utilsObject.getSizeOfElement(equity.page, equity.EQUITY_FIXTURES.priceBoardStocks);
            for (let index = 0; index < size; index++) {

                var priceHeaders = ["Giá", "TĐ", "%TĐ", "Mua", "Bán"];
                var priceValues = [];
                var stockRowXpath = `${equity.EQUITY_FIXTURES.priceBoardStocks}[${index + 1}]`;
                var stockRowName = await utilsObject.getTextOfElement(equity.page, stockRowXpath);
                await equity.selectPriceBoardAtStockCode(stockRowName);
                var currentStock = await utilsObject.getValueOfElement(equity.page, equity.EQUITY_FIXTURES.SEARCH_STOCK_1);
                await expect(currentStock).toEqual(stockRowName);

                await equity.setPageIntercept();
                await equity.sleep(1);
                var floorCeilReferValues = await equity.getFloorCeilReferValues();
                var priceBoardRow = equity.EQUITY_FIXTURES.priceBoardRowIdxColumnName.replace('%stock_code', currentStock);
                var lastPriceXpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.priceBoardLastPriceCol);
                var changeXpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.priceBoardChange);
                var percentXpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.priceBoardChangePercent);
                var buy1Xpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.priceBoardBestBidPrice1);
                var sell1Xpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.priceBoardBestOfferPrice1);

                priceValues.push(await utilsObject.getValueColorBgColor(equity.page, lastPriceXpath));
                priceValues.push(await utilsObject.getValueColorBgColor(equity.page, changeXpath));
                priceValues.push(await utilsObject.getValueColorBgColor(equity.page, percentXpath));
                priceValues.push(await utilsObject.getValueColorBgColor(equity.page, buy1Xpath));
                priceValues.push(await utilsObject.getValueColorBgColor(equity.page, sell1Xpath));

                var failList = await equity.checkPricesColors(floorCeilReferValues[0], floorCeilReferValues[1], floorCeilReferValues[2],
                    priceHeaders, priceValues);
                if (failList.length > 0) {
                    await equity.page.screenshot({ path: `logs/price_board_equity_${favouriteItem}_${currentStock}.png` });
                    await utilsObject.writeFailListToLogFile(currentStock, failList, 'price_board_equity_');
                } else {
                    await utilsObject.writeMsgToLogFile(`${favouriteItem}_${currentStock} is passed`, 'price_board_equity_');
                }

                await equity.removePageIntercept();
            };
        });
    });

    it('Warrant market', async () => {
        await equity.gotoWarrantMarket();
        await equity.selectOneStockView();
        await equity.sleep(1);
        var wsize = await utilsObject.getSizeOfElement(equity.page, equity.EQUITY_FIXTURES.priceBoardStocks);
        for (let windex = 0; windex < wsize; windex++) {
            var priceHeaders = ["Giá", "TĐ", "%TĐ", "+/-UL(%)"];
            var priceValues = [];
            var stockRowXpath = `${equity.EQUITY_FIXTURES.priceBoardStocks}[${windex + 1}]`;
            var stockRowName = await utilsObject.getTextOfElement(equity.page, stockRowXpath);
            await equity.selectPriceBoardAtStockCode(stockRowName);
            var currentStock = await utilsObject.getValueOfElement(equity.page, equity.EQUITY_FIXTURES.SEARCH_STOCK_1);
            await expect(currentStock).toEqual(stockRowName);

            await equity.setPageIntercept();
            await equity.sleep(3);
            var floorCeilReferValues = await equity.getFloorCeilReferValues();
            var priceBoardRow = equity.EQUITY_FIXTURES.priceBoardRowIdxColumnName.replace('%stock_code', currentStock);
            var lastPriceXpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.priceBoardLastPriceCol);
            var changeXpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.priceBoardChange);
            var percentXpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.priceBoardChangePercent);
            var ulPercentXpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.ULPercent);

            priceValues.push(await utilsObject.getValueColorBgColor(equity.page, lastPriceXpath));
            priceValues.push(await utilsObject.getValueColorBgColor(equity.page, changeXpath));
            priceValues.push(await utilsObject.getValueColorBgColor(equity.page, percentXpath));
            priceValues.push(await utilsObject.getValueColorBgColor(equity.page, ulPercentXpath));

            var failList = await equity.checkPricesColors(floorCeilReferValues[0], floorCeilReferValues[1], floorCeilReferValues[2],
                priceHeaders, priceValues);
            if (failList.length > 0) {
                await equity.page.screenshot({ path: `logs/price_board_warrant_${favouriteItem}_${currentStock}.png` });
                await utilsObject.writeFailListToLogFile(currentStock, failList, 'price_board_warrant_');
            } else {
                await utilsObject.writeMsgToLogFile(`${currentStock} is passed`, 'price_board_warrant_');
            }
            await equity.removePageIntercept();
        };
    });

    it('ETF market', async () => {
        await equity.gotoETFMarket();
        await equity.selectOneStockView();
        await equity.sleep(1);

        var esize = await utilsObject.getSizeOfElement(equity.page, equity.EQUITY_FIXTURES.priceBoardStocks);
        for (let eindex = 0; eindex < esize; eindex++) {
            var priceHeaders = ["Giá", "TĐ", "%TĐ", "Mua", "Bán"];
            var priceValues = [];
            var stockRowXpath = `${equity.EQUITY_FIXTURES.priceBoardStocks}[${eindex + 1}]`;
            var stockRowName = await utilsObject.getTextOfElement(equity.page, stockRowXpath);
            await equity.selectPriceBoardAtStockCode(stockRowName);
            var currentStock = await utilsObject.getValueOfElement(equity.page, equity.EQUITY_FIXTURES.SEARCH_STOCK_1);
            await expect(currentStock).toEqual(stockRowName);

            await equity.setPageIntercept();
            await equity.sleep(3);
            var floorCeilReferValues = await equity.getFloorCeilReferValues();
            var priceBoardRow = equity.EQUITY_FIXTURES.priceBoardRowIdxColumnName.replace('%stock_code', currentStock);
            var lastPriceXpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.priceBoardLastPriceCol);
            var changeXpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.priceBoardChange);
            var percentXpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.priceBoardChangePercent);
            var buy1Xpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.priceBoardBestBidPrice1);
            var sell1Xpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.priceBoardBestOfferPrice1);

            priceValues.push(await utilsObject.getValueColorBgColor(equity.page, lastPriceXpath));
            priceValues.push(await utilsObject.getValueColorBgColor(equity.page, changeXpath));
            priceValues.push(await utilsObject.getValueColorBgColor(equity.page, percentXpath));
            priceValues.push(await utilsObject.getValueColorBgColor(equity.page, buy1Xpath));
            priceValues.push(await utilsObject.getValueColorBgColor(equity.page, sell1Xpath));

            var failList = await equity.checkPricesColors(floorCeilReferValues[0], floorCeilReferValues[1], floorCeilReferValues[2],
                priceHeaders, priceValues);
            if (failList.length > 0) {
                await equity.page.screenshot({ path: `logs/price_board_etf_${favouriteItem}_${currentStock}.png` });
                await utilsObject.writeFailListToLogFile(currentStock, failList, 'price_board_etf_');
            } else {
                await utilsObject.writeMsgToLogFile(`${currentStock} is passed`, 'price_board_etf_');
            }
            await equity.removePageIntercept();
        };
    });

    it('Future market', async () => {
        await equity.gotoFutureMarket();
        await equity.selectOneStockView();
        await equity.sleep(1);


        var fsize = await utilsObject.getSizeOfElement(equity.page, equity.EQUITY_FIXTURES.priceBoardStocks);
        for (let findex = 0; findex < fsize; findex++) {
            var priceHeaders = ["Giá", "TĐ", "%TĐ", "Độ lệch"];
            var priceValues = [];
            var stockRowXpath = `${equity.EQUITY_FIXTURES.priceBoardStocks}[${findex + 1}]`;
            var stockRowName = await utilsObject.getTextOfElement(equity.page, stockRowXpath);
            await equity.selectPriceBoardAtStockCode(stockRowName);
            var currentStock = await utilsObject.getValueOfElement(equity.page, equity.EQUITY_FIXTURES.SEARCH_STOCK_1);
            await expect(currentStock).toEqual(stockRowName);

            await equity.setPageIntercept();
            await equity.sleep(3);
            var floorCeilReferValues = await equity.getFloorCeilReferValues();
            var priceBoardRow = equity.EQUITY_FIXTURES.priceBoardRowIdxColumnName.replace('%stock_code', currentStock);
            var lastPriceXpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.priceBoardLastPriceCol);
            var changeXpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.priceBoardChange);
            var percentXpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.priceBoardChangePercent);
            var basicXpath = priceBoardRow.replace('%column_name', equity.EQUITY_FIXTURES.Basis);

            priceValues.push(await utilsObject.getValueColorBgColor(equity.page, lastPriceXpath));
            priceValues.push(await utilsObject.getValueColorBgColor(equity.page, changeXpath));
            priceValues.push(await utilsObject.getValueColorBgColor(equity.page, percentXpath));
            priceValues.push(await utilsObject.getValueColorBgColor(equity.page, basicXpath));

            var failList = await equity.checkPricesColors(floorCeilReferValues[0], floorCeilReferValues[1], floorCeilReferValues[2],
                priceHeaders, priceValues);
            if (failList.length > 0) {
                await equity.page.screenshot({ path: `logs/price_board_future_${favouriteItem}_${currentStock}.png` });
                await utilsObject.writeFailListToLogFile(currentStock, failList, 'price_board_future_');
            } else {
                await utilsObject.writeMsgToLogFile(`${currentStock} is passed`, 'price_board_future_');
            }
            await equity.removePageIntercept();

        };
    });

})