const pt = require('puppeteer');
const Utils = require('./utils');


module.exports = class Equity {
    constructor(delayTime = 60) {
        this.browser = null;
        this.page = null;
        this.delayTime = delayTime;
        this.EQUITY_FIXTURES = require('../fixtures/trading/locators/equity_order_page.json');
        this.LOG_IN_LOG_OUT_FIXTURES = require('../fixtures/trading/locators/login_page_uat.json')
    };

    sleep(s) {
        return new Promise(resolve => {
            setTimeout(resolve, s * 1000);
        });
    };


    async launchBrowser() {
        console.log("Launch browser");
        this.browser = await pt.launch({ headless: false, args: ['--start-maximized'] });
        this.page = await this.browser.newPage();
        await this.page.setViewport({ width: 1920, height: 1060 });
        await this.page.goto(this.LOG_IN_LOG_OUT_FIXTURES.url);
        await this.page.waitForNetworkIdle();
        await this.sleep(2);

        await this.page.screenshot({ path: 'logs/hsc.png' });
        return this.page.url();
    };

    async getTitle() {
        return await this.page.title();
    };

    async getTextWidth() {
        var ele = document.createElement('canvas');
        ele.getContext().font()
    }

    async clickCloseBtnIfAny() {
        await this.page.$x('//button[@title="Đóng"]').then((closeBtn) => {
            if (closeBtn.length > 0) {
                closeBtn[0].click({ delay: this.delayTime });
            }
        })
    };

    async logOut() {
        const logoutIcon = await this.page.$x(this.LOG_IN_LOG_OUT_FIXTURES.logoutIcon);
        if (logoutIcon.length > 0) {
            await logoutIcon[0].click({ delay: this.delayTime });
            await this.sleep(1);
            await this.page.evaluate(function (logoutText) {
                Array.from(document.querySelectorAll('li')).filter(li => {
                    return li.innerText == logoutText;
                }).forEach(element => {
                    if (element) element.click();
                });
            }, this.LOG_IN_LOG_OUT_FIXTURES.logoutText);
            await this.sleep(1);
        }
    };

    async closeBrowser() {
        await this.browser.close();
    };

    async login(username, pwd) {
        console.log(`Login with ${username} / ${pwd}`);

        const iframeElement = await this.page.waitForSelector(this.LOG_IN_LOG_OUT_FIXTURES.iframe);
        const iframe = await iframeElement.contentFrame();

        const usernameEle = await iframe.$(this.LOG_IN_LOG_OUT_FIXTURES.username);
        await usernameEle.click({ clickCount: 2 });
        await usernameEle.type(username, { delay: this.delayTime });

        const passwordEle = await iframe.$(this.LOG_IN_LOG_OUT_FIXTURES.password);
        await passwordEle.click({ clickCount: 2 });
        await passwordEle.type(pwd, { delay: this.delayTime });

        const loginBtn = await iframe.$x(this.LOG_IN_LOG_OUT_FIXTURES.loginBtn);
        await loginBtn[0].click();
        await this.page.waitForNetworkIdle();
        await this.sleep(20);

        await this.page.screenshot({ path: 'logs/login.png' });
        await this.page.waitForNetworkIdle();
        const curUrl = await this.page.url();
        return curUrl;
    };

    async reLoginIfAnyAndGoToEquity(username, pwd) {
        const curUrl = await this.page.url();
        if (curUrl.includes('/login')) {
            await this.login(username, pwd);
            await this.clickEquityButton();
        }
        return await this.page.url();
    }

    async getCurrentUrl() {
        return await this.page.url();
    }

    async clickEquityButton() {
        console.log("Go to equity page");
        const equityBtn = await this.page.$x(this.EQUITY_FIXTURES.equityBtnName);
        await equityBtn[0].click();
        await this.sleep(3);
        await this.page.waitForNetworkIdle();
    };

    async clickConfirmButtonIfAny() {
        const confirmBtn = await this.page.$x(this.EQUITY_FIXTURES.confirmBtn);
        if (confirmBtn.length > 0) {
            await confirmBtn[0].click();
            await this.sleep(2);
        }
    };

    async searchStockCode(code) {
        const codeTxtBox = await this.page.$x(this.EQUITY_FIXTURES.searchStockTxtBox);
        await codeTxtBox[0].click({ clickCount: 2 });
        await codeTxtBox[0].type(`${code}`, { delay: this.delayTime });
        await codeTxtBox[0].press('Enter', { delay: this.delayTime });
        await this.sleep(1);
        const actualCode = await (await codeTxtBox[0].getProperty('value')).jsonValue();
        return actualCode;

    };

    async setPageIntercept() {
        await this.page.setRequestInterception(true);
        this.page.on('request', interceptedRequest => {
            if (interceptedRequest.url().includes('streaming-api-uat.hsc.com.vn'))
                interceptedRequest.abort();
            else
                interceptedRequest.continue();
        });

    };

    async removePageIntercept() {
        await this.page.setRequestInterception(false);
    }

    async getFloorCeilRefer() {
        var more_info_locator = this.EQUITY_FIXTURES.priceTable;

        const floor_ceil_refer = await this.page.$$eval(more_info_locator, elements => {
            var refer_index = 1;
            var refer = [];
            refer.push(elements[refer_index].textContent);
            refer.push(window.getComputedStyle(elements[refer_index]).color);
            refer.push(window.getComputedStyle(elements[refer_index]).backgroundColor);

            var ceil_index = 4;
            var ceil = [];
            ceil.push(elements[ceil_index].textContent);
            ceil.push(window.getComputedStyle(elements[ceil_index]).color);
            ceil.push(window.getComputedStyle(elements[ceil_index]).backgroundColor);

            var floor_index = 6;
            var floor = [];
            floor.push(elements[floor_index].textContent);
            floor.push(window.getComputedStyle(elements[floor_index]).color);
            floor.push(window.getComputedStyle(elements[floor_index]).backgroundColor);

            return [floor, ceil, refer];
        });
        return floor_ceil_refer;
    };

    async getInnoChangeValues() {
        var inno_change_locator = this.EQUITY_FIXTURES.innoChange;
        const inno_change_values = this.page.$$eval(inno_change_locator, elements => {
            var lastPrice = [];
            var lastPriceIndex = 0;
            lastPrice.push(elements[lastPriceIndex].textContent);
            lastPrice.push(window.getComputedStyle(elements[lastPriceIndex]).color);
            lastPrice.push(window.getComputedStyle(elements[lastPriceIndex]).backgroundColor);

            var deviation = [];
            var deviationIndex = 1;
            deviation.push(elements[deviationIndex].textContent);
            deviation.push(window.getComputedStyle(elements[deviationIndex]).color);
            deviation.push(window.getComputedStyle(elements[deviationIndex]).backgroundColor);

            var deviation_percent = [];
            var percentIndex = 2;
            deviation_percent.push(elements[percentIndex].textContent);
            deviation_percent.push(window.getComputedStyle(elements[percentIndex]).color);
            deviation_percent.push(window.getComputedStyle(elements[percentIndex]).backgroundColor);

            return [lastPrice, deviation, deviation_percent];
        });
        return inno_change_values;
    };

    async getOpenHighestLowestAvgPrices() {
        var sliderTitleLocator = '.more-info .slider-title span';
        var priceTableLocator = this.EQUITY_FIXTURES.priceTable;
        const highestLowest = await this.page.$$eval(sliderTitleLocator, elements => {
            var highestPriceIndex = 0;
            var highestPrice = [];
            highestPrice.push(elements[highestPriceIndex].textContent);
            highestPrice.push(window.getComputedStyle(elements[highestPriceIndex]).color);
            highestPrice.push(window.getComputedStyle(elements[highestPriceIndex]).backgroundColor);

            var lowestPriceIndex = 1;
            var lowestPrice = [];
            lowestPrice.push(elements[lowestPriceIndex].textContent);
            lowestPrice.push(window.getComputedStyle(elements[lowestPriceIndex]).color);
            lowestPrice.push(window.getComputedStyle(elements[lowestPriceIndex]).backgroundColor);
            return [highestPrice, lowestPrice];
        });

        const openAvarage = await this.page.$$eval(priceTableLocator, elements => {
            var openPriceIndex = 0;
            var openPrice = [];
            openPrice.push(elements[openPriceIndex].textContent);
            openPrice.push(window.getComputedStyle(elements[openPriceIndex]).color);
            openPrice.push(window.getComputedStyle(elements[openPriceIndex]).backgroundColor);

            var averagePriceIndex = 3;
            var averagePrice = [];
            averagePrice.push(elements[averagePriceIndex].textContent);
            averagePrice.push(window.getComputedStyle(elements[averagePriceIndex]).color);
            averagePrice.push(window.getComputedStyle(elements[averagePriceIndex]).backgroundColor);
            return [openPrice, averagePrice];
        });

        var openHighestLowestAvgPrices = [];
        openHighestLowestAvgPrices.push(openAvarage[0]);
        openHighestLowestAvgPrices.push(highestLowest[0]);
        openHighestLowestAvgPrices.push(highestLowest[1]);
        openHighestLowestAvgPrices.push(openAvarage[1]);
        return openHighestLowestAvgPrices;
    }

    async getPriceVolumnes() {
        const lastest_price_volumne_table_locator = this.EQUITY_FIXTURES.lastesPriceVolumnTable;
        const priceVolumneValues = this.page.$$eval(lastest_price_volumne_table_locator, elements => {
            var priceValues = [];
            var price_1 = [];
            price_1.push(elements[0].textContent);
            price_1.push(window.getComputedStyle(elements[0]).color);
            price_1.push(window.getComputedStyle(elements[0]).backgroundColor);

            var price_2 = [];
            price_2.push(elements[2].textContent);
            price_2.push(window.getComputedStyle(elements[2]).color);
            price_2.push(window.getComputedStyle(elements[2]).backgroundColor);

            var price_3 = [];
            price_3.push(elements[4].textContent);
            price_3.push(window.getComputedStyle(elements[4]).color);
            price_3.push(window.getComputedStyle(elements[4]).backgroundColor);

            var price_4 = [];
            price_4.push(elements[7].textContent);
            price_4.push(window.getComputedStyle(elements[7]).color);
            price_4.push(window.getComputedStyle(elements[7]).backgroundColor);

            var price_5 = [];
            price_5.push(elements[9].textContent);
            price_5.push(window.getComputedStyle(elements[9]).color);
            price_5.push(window.getComputedStyle(elements[9]).backgroundColor);

            var price_6 = [];
            price_6.push(elements[11].textContent);
            price_6.push(window.getComputedStyle(elements[11]).color);
            price_6.push(window.getComputedStyle(elements[11]).backgroundColor);

            priceValues.push(price_1, price_2, price_3, price_4, price_5, price_6);

            var buySellValues = [];
            var buy_1 = [];
            buy_1.push(elements[6].textContent);
            buy_1.push(window.getComputedStyle(elements[6]).color);
            buy_1.push(window.getComputedStyle(elements[6]).backgroundColor);

            var buy_2 = [];
            buy_2.push(elements[8].textContent);
            buy_2.push(window.getComputedStyle(elements[8]).color);
            buy_2.push(window.getComputedStyle(elements[8]).backgroundColor);

            var buy_3 = [];
            buy_3.push(elements[10].textContent);
            buy_3.push(window.getComputedStyle(elements[10]).color);
            buy_3.push(window.getComputedStyle(elements[10]).backgroundColor);

            var sell_1 = [];
            sell_1.push(elements[1].textContent);
            sell_1.push(window.getComputedStyle(elements[1]).color);
            sell_1.push(window.getComputedStyle(elements[1]).backgroundColor);

            var sell_2 = [];
            sell_2.push(elements[3].textContent);
            sell_2.push(window.getComputedStyle(elements[3]).color);
            sell_2.push(window.getComputedStyle(elements[3]).backgroundColor);

            var sell_3 = [];
            sell_3.push(elements[5].textContent);
            sell_3.push(window.getComputedStyle(elements[5]).color);
            sell_3.push(window.getComputedStyle(elements[5]).backgroundColor);

            buySellValues.push(buy_1, buy_2, buy_3, sell_1, sell_2, sell_3);

            return [priceValues, buySellValues];
        });

        return priceVolumneValues;
    }

    async getExpectedColor(floorValue, ceilValue, referValue, sValue) {
        var expectedColor;

        if (sValue != "-") {
            let fValue = parseFloat(sValue);
            if (sValue.includes('+')) {
                expectedColor = this.EQUITY_FIXTURES.greenColor;
            }
            else if (sValue.includes('-')) {
                expectedColor = this.EQUITY_FIXTURES.redColor;
            }
            else if ((sValue == 'ATO') || (sValue == 'ATC')) {
                expectedColor = this.EQUITY_FIXTURES.whiteColor;
            } else if (fValue == floorValue) {
                expectedColor = this.EQUITY_FIXTURES.cyanColor;
            } else if ((fValue > floorValue) && (fValue < referValue)) {
                expectedColor = this.EQUITY_FIXTURES.redColor;
            } else if (fValue == referValue) {
                expectedColor = this.EQUITY_FIXTURES.yellowColor;
            } else if ((fValue > referValue) && (fValue < ceilValue)) {
                expectedColor = this.EQUITY_FIXTURES.greenColor;
            } else if (fValue == ceilValue) {
                expectedColor = this.EQUITY_FIXTURES.violetColor;
            } else if (fValue == 0) {
                expectedColor = this.EQUITY_FIXTURES.yellowColor;
            }
            else {
                expectedColor = `NOT FOUND suitable color for ${sValue}`
            }
        } else {
            expectedColor = this.EQUITY_FIXTURES.yellowColor;
        }
        return expectedColor;
    }

    async checkLatestDevPercent(latestPrice, deviation, percent) {
        let failList = [];
        let latestPriceColor = latestPrice[1];
        let deviationColor = deviation[1];
        let percentColor = percent[1];
        if (latestPriceColor != deviationColor
            || deviationColor != percentColor
            || deviationColor != percentColor) {
            failList.push(`latestPrice: ${latestPrice} - deviationValue: ${deviation} - percentValue: ${percent}`);
        }
        return failList;
    }

    async checkPricesColors(floor, ceil, refer, headers, curDatas) {
        let floorValue = parseFloat(floor[0]);
        let referValue = parseFloat(refer[0]);
        let ceilValue = parseFloat(ceil[0]);

        let failList = [];
        for (let i = 0; i < curDatas.length; i++) {
            let curColor = curDatas[i][1];
            let expectedColor = await this.getExpectedColor(floorValue, ceilValue, referValue, curDatas[i][0]);
            if (curColor != expectedColor) {
                failList.push(`floor: ${floorValue} - refer: ${referValue} - ceil: ${ceilValue} - cur: ${curDatas[i][0]} (${curDatas[i]}).\nColor of ${headers[i]} should be ${expectedColor}. Actual color is ${curColor}`);
            }
        }
        return failList;
    }

    async checkFloorCeilRefeColors(floor, ceil, refer) {
        let failList = [];
        if (ceil[1] != this.EQUITY_FIXTURES.violetColor) {
            failList.push(`Ceil's color is wrong. Expected: ${this.EQUITY_FIXTURES.violetColor}, actual: ${ceil[1]}`);
        }
        if (refer[1] != this.EQUITY_FIXTURES.yellowColor) {
            failList.push(`Refer's color is wrong. Expected: ${this.EQUITY_FIXTURES.yellowColor}, actual: ${refer[1]}`);
        }
        if (floor[1] != this.EQUITY_FIXTURES.cyanColor) {
            failList.push(`Floor's color is wrong. Expected: ${this.EQUITY_FIXTURES.cyanColor}, actual: ${floor[1]}`);
        }
        return failList;

    }

    async checkBuySellNumbersColors(headers, values) {
        let failList = [];
        //check buy
        for (let i = 0; i < 3; i++) {
            if (values[i][1] != this.EQUITY_FIXTURES.whiteColor) {
                failList.push(`${headers[i]} ${values[i][0]} is wrong text color. Expected: ${this.EQUITY_FIXTURES.whiteColor}, actual: ${values[i][1]}`);
            }
            // if (bgColors[i] != greenColor) {
            //     failList.push(`${headers[i]} ${values[i]} is wrong background color. Expected: ${greenColor}, actual: ${bgColors[i]}`)
            // }
        }
        //check sell
        for (let i = 3; i < values.length; i++) {
            if (values[i][1] != this.EQUITY_FIXTURES.whiteColor) {
                failList.push(`${headers[i]} ${values[i][0]} is wrong text color. Expected: ${this.EQUITY_FIXTURES.whiteColor}, actual: ${values[i][1]}`);
            }
            // if (bgColors[i] != redColor) {
            //     failList.push(`${headers[i]} ${values[i]} is wrong background color. Expected: ${redColor}, actual: ${bgColors[i]}`)
            // }
        }
        return failList;

    }


    async getNumberRowOfTradeLog() {
        var numberOfRows = this.page.$$eval(this.EQUITY_FIXTURES.tradeLogAllRows, elements => {
            return elements.length;
        });
        return numberOfRows;
    }

    async scrollToLastRowOfTradeLog() {
        await this.page.$$eval(this.EQUITY_FIXTURES.tradeLogDisplayedRows, elements => {
            if (elements.length > 0) {
                elements[elements.length - 1].scrollIntoView();
            }
        });
        await this.sleep(1);
    }

    async checkPriceColorOfTradeLog() {
        var failList = [];

        const floor_ceil_refer = await this.getFloorCeilRefer();
        const pricesData = this.page.$$eval(this.EQUITY_FIXTURES.tradeLogPrices, elements => {
            var listData = [];
            // start to check from 1, because 0 is the header
            for (var i = 1; i < elements.length; i++) {
                listData.push([elements[i].textContent, window.getComputedStyle(elements[i]).color]);
            }
            return listData;
        });


        for (var i = 0; i < pricesData.length; i++) {
            let sValue = pricesData[i][0];
            let actualColor = pricesData[i][1];
            let expectedColor = await getExpectedColor(floor_ceil_refer[0], floor_ceil_refer[1], floor_ceil_refer[2], sValue)
            if (actualColor != expectedColor) {
                failList.push(`${sValue} is wrong color. Actual: ${actualColor}, expected: ${expectedColor}`);
            }
        }
        return failList;
    }

    async checkTypeTradeColorOfTradeLog() {
        var failList = [];
        const typesData = this.page.$$eval(this.EQUITY_FIXTURES.tradeLogTypes, elements => {
            var listData = [];
            // start to check from 1, because 0 is the header
            for (var i = 1; i < elements.length; i++) {
                listData.push([elements[i].textContent, window.getComputedStyle(elements[i]).color]);
            }
            return listData;
        });

        for (var i = 0; i < typesData.length; i++) {
            let sValue = typesData[i][0];
            let actualColor = typesData[i][1];
            let expectedColor = 'NOT_FOUND';
            if (sValue == '') {
                continue;
            } else if (sValue == 'M') {
                expectedColor = this.EQUITY_FIXTURES.greenColor;
            } else if (sValue == 'B') {
                expectedColor = this.EQUITY_FIXTURES.redColor;
            }

            if (actualColor != expectedColor) {
                failList.push(`${sValue} is wrong color. Actual: ${actualColor}, expected: ${expectedColor}`);
            }
        }
        return failList;
    }


};