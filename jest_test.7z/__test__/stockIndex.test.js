var WebSocketClient = require('websocket').client;
var pt = require('puppeteer');
//var it = require('jest-retries');
require('jest')
var StockIndexPage = require('./stockIndex');

jest.setTimeout(120 * 1000);

describe('Stock Index of DTI Team', () => {

    var stockIndex = new StockIndexPage();
  

    beforeAll(async () => {
        var url = await stockIndex.launchBrowser();
        await expect(url).toContain('/stock-index');
    });


    afterAll(async () => {
        await stockIndex.closeBrowser();
    });



    var stocks = ["AAT", "ACG"];
    for (const stockCode of stocks) {
        it(`${stockCode}: Test case 2`, async () => {
            //const isPassed = await stockIndex.monitorDisplayStock(stockCode);
            //await expect(isPassed).toEqual(true);

            await stockIndex.monitorHTMLText(stockCode);
            
        });
    };

});