const pt = require('puppeteer');
const utilsObjectClass = require('./utils')

module.exports = class StockIndex {
    constructor(delayTime = 60) {
        this.browser = null;
        this.page = null;
        this.delayTime = delayTime;
        this.stockIndexUrl = 'http://172.19.6.2:3001/stock-index';
        this.utilsObject = new utilsObjectClass();
    }

    sleep(s) {
        return new Promise(resolve => {
            setTimeout(resolve, s * 1000);
        });
    };

    async launchBrowser() {
        console.log(`Launch browser with URL: ${this.stockIndexUrl} ...`);
        this.browser = await pt.launch({ headless: false, args: ['--start-maximized'] });
        this.page = await this.browser.newPage();
        await this.page.setViewport({ width: 1920, height: 1060 });
        await this.page.goto(this.stockIndexUrl);
        await this.page.waitForNetworkIdle();
        await this.sleep(5);
        return this.page.url();
    };

    async closeBrowser() {
        await this.browser.close();
    };

    async monitorHTMLText(stockCode, count = 2) {
        var passedStocks = [];
        //capturing websocket data
        const clientCDP = await this.page.target().createCDPSession();
        await clientCDP.send('Network.enable');
        await clientCDP.send('Page.enable');
        await this.sleep(1);
        var expectedValues = [];


        clientCDP.on(
            'Network.webSocketFrameReceived',
            (wsd) => logConsole(wsd)
        );


        const logConsole = async (wsd) => {
            var recievedTimeYYYYMMDDHHMMSSSSSS = new Date(wsd.timestamp * 1000000).toLocaleTimeString("en-US");
            console.log(`Network.webSocketFrameReceived, requestId: ${wsd.requestId}, timestamp: ${wsd.timestamp} - ${recievedTimeYYYYMMDDHHMMSSSSSS}`);
            //remove redundant characters
            var sData = wsd.response.payloadData.substring(17, wsd.response.payloadData.length - 1).trim();
            var wsJSONData = JSON.parse(sData);
            for (var stockData of wsJSONData.data) {
                if (stockCode == stockData.symbol) {
                    expectedValues.push([stockData.bid2, stockData.bid3]);
                    console.log(`${stockCode}. Expected values [bid2-bid3]: ${stockData.bid2} - ${stockData.bid3}`);
                };
            }
        }

        const bid3Page = await this.utilsObject.getTextOfElement(this.page, `(//div[@data-id="${stockCode}"]//div[@data-field="bid3"])//*[not(*)]`);
        const bid2Page = await this.utilsObject.getTextOfElement(this.page, `(//div[@data-id="${stockCode}"]//div[@data-field="bid2"])//*[not(*)]`);
        var actualValues = [bid2Page, bid3Page];
        console.log(`${stockCode}. FAILED: ${bid2Page} - ${bid3Page}`);
        console.log(`${stockCode}.\nExpected: ${expectedValues}.\nActual: ${actualValues}`);























        // clientCDP.on('Network.webSocketFrameReceived', ({ requestId, timestamp, response }) => {
        //     var recievedTime = new Date(timestamp * 1000000).toLocaleTimeString("en-US");
        //     //remove redundant characters
        //     var wsData = response.payloadData.substring(2).trim();
        //     var wsJSONData = JSON.parse(wsData);
        //     wsJSONData[1].data.forEach(async (element) => {
        //         var stockCodeOnPage = element.symbol;
        //         if (strStocks.includes(stockCodeOnPage)) {
        //             xconsole.log(`Network.webSocketFrameReceived, requestId: ${requestId}, timestamp: ${timestamp} - ${recievedTime}, response.payloadData: ${JSON.stringify(element)}`);
        //             //capturing value of HTML element
        //             for (var i = count; i > 0; i--) {
        //                 var bid3Page = await this.utilsObject.getTextOfElement(this.page, `(//div[@data-id="${stockCodeOnPage}"]//div[@data-field="bid3"])`);
        //                 var bid2Page = await this.utilsObject.getTextOfElement(this.page, `(//div[@data-id="${stockCodeOnPage}"]//div[@data-field="bid2"])`);
        //                 console.log(`${stockCodeOnPage} - bid3: is displayed with value: ${bid3Page}`);
        //                 console.log(`${stockCodeOnPage} - bid2: is displayed with value: ${bid2Page}`);
        //                 if (element.bid3 == bid3Page
        //                     && element.bid2 == bid2Page) {
        //                     passedStocks.push(stockCodeOnPage);
        //                     console.log(`${stockCodeOnPage} - bid3: is displayed as expected value ----> PASSED`);
        //                     console.log(`${stockCodeOnPage} - bid2: is displayed as expected value ----> PASSED`);
        //                     i = 0;
        //                 } else {
        //                     this.sleep(1 / count);
        //                 }

        //             };
        //         };
        //     });
        // });
        // console.log("-------------------------- passedStocks: " + passedStocks);
        //return passedStocks;
    };


    async monitorDisplayStock(stock, retries = 2) {
        //capturing websocket data
        const clientCDP = await this.page.target().createCDPSession();
        await clientCDP.send('Network.enable');
        await clientCDP.send('Page.enable');

        var isPassed;
        clientCDP.on('Network.webSocketFrameReceived', async ({ requestId, timestamp, response }) => {
            var recievedTime = new Date(timestamp * 1000000).toLocaleTimeString("en-US");
            //remove redundant characters
            var wsData = response.payloadData.substring(2).trim();
            var wsJSONData = JSON.parse(wsData);

            isPassed = false;
            for (const element of wsJSONData[1].data) {
                // wsJSONData[1].data.forEach(async (element) => {
                var stockCodeOnPage = element.symbol;

                if (stock == stockCodeOnPage) {
                    //console.log(`------------- ${stockCodeOnPage}`);
                    //     //console.log(`Network.webSocketFrameReceived, requestId: ${requestId}, timestamp: ${timestamp} - ${recievedTime}, response.payloadData: ${JSON.stringify(element)}`);
                    //     //capturing value of HTML element
                    var bid3Page = await this.utilsObject.getTextOfElement(this.page, `(//div[@data-id="${stockCodeOnPage}"]//div[@data-field="bid3"])`);
                    var bid2Page = await this.utilsObject.getTextOfElement(this.page, `(//div[@data-id="${stockCodeOnPage}"]//div[@data-field="bid2"])`);
                    var bid1Page = await this.utilsObject.getTextOfElement(this.page, `(//div[@data-id="${stockCodeOnPage}"]//div[@data-field="bid1"])`);
                    var ask3Page = await this.utilsObject.getTextOfElement(this.page, `(//div[@data-id="${stockCodeOnPage}"]//div[@data-field="ask3"])`);
                    var ask2Page = await this.utilsObject.getTextOfElement(this.page, `(//div[@data-id="${stockCodeOnPage}"]//div[@data-field="ask2"])`);
                    var ask1Page = await this.utilsObject.getTextOfElement(this.page, `(//div[@data-id="${stockCodeOnPage}"]//div[@data-field="ask1"])`);
                    //console.log(`${stockCodeOnPage} - Displayed values bid3-bid2-bid1-ask3-ask2-ask1 (${bid3Page}-${bid2Page}-${bid1Page}-${ask3Page}-${ask2Page}-${ask1Page})`);
                    if (element.bid3 == bid3Page
                        && element.bid2 == bid2Page
                        && element.bid1 == bid1Page
                        && element.ask3 == ask3Page
                        && element.ask2 == ask2Page
                        && element.ask1 == ask1Page
                    ) {
                        //console.log(`${stockCodeOnPage} - bid3-bid2-bid1-ask3-ask2-ask1 are displayed as expected value. ----> PASSED`);
                        isPassed = true;
                    } else {
                        this.sleep(1 / retries);
                    }
                };
            };
        });
        return isPassed;
    };
}