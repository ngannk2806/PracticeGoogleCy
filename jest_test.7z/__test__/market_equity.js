const pt = require('puppeteer');
const Base = require('./base_page');
const Utils = require('./utils');

module.exports = class EquityMarket extends Base {
    utilsObject = new Utils();

    constructor(delayTime = 60) {
        super();
        this.EQUITY_FIXTURES = require('../fixtures/trading/locators/equity_market_page.json');
    };



    async gotoEquityMarket() {
        var equityBtn = this.EQUITY_FIXTURES.equity_button;
        await this.page.$x(equityBtn).then((equityBtnElement) => {
            if (equityBtnElement.length > 0) {
                equityBtnElement[0].click({ delay: this.delayTime });
            }
        });
    }

    async gotoFutureMarket() {
        var btn = this.EQUITY_FIXTURES.futures_button;
        await this.page.$x(btn).then((btnEle) => {
            if (btnEle.length > 0) {
                btnEle[0].click({ delay: this.delayTime });
            }
        });
    }

    async gotoWarrantMarket() {
        var btn = this.EQUITY_FIXTURES.warrant_button;
        await this.page.$x(btn).then((btnEle) => {
            if (btnEle.length > 0) {
                btnEle[0].click({ delay: this.delayTime });
            }
        });
    }

    async gotoETFMarket() {
        var btn = this.EQUITY_FIXTURES.etf_button;
        await this.page.$x(btn).then((btnEle) => {
            if (btnEle.length > 0) {
                btnEle[0].click({ delay: this.delayTime });
            }
        });
    }

    async searchStockCode(code, index = 1) {
        var codeTxtBox = "";
        if (index == 1) {
            codeTxtBox = await this.page.$x(this.EQUITY_FIXTURES.SEARCH_STOCK_1);
        } else {
            codeTxtBox = await this.page.$x(this.EQUITY_FIXTURES.SEARCH_STOCK_2);
        }
        await codeTxtBox[0].click({ clickCount: 2 });
        await codeTxtBox[0].type(`${code}`, { delay: this.delayTime });
        await codeTxtBox[0].press('Enter', { delay: this.delayTime });
        await this.sleep(2);
        const actualCode = await (await codeTxtBox[0].getProperty('value')).jsonValue();

        return actualCode;
    };

    async getFloorCeilReferValues() {
        var floorCeilRefer = [];
        floorCeilRefer.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.MORE_INFO_FLOOR_PRICE));
        floorCeilRefer.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.MORE_INFO_CEIL_PRICE));
        floorCeilRefer.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.MORE_INFO_REFER_PRICE));
        return floorCeilRefer;
    };

    async getPricesValues() {
        // const priceHeaders = ["Giá khớp", "Thay đổi giá", "% thay đổi giá", "Giá bán 1", "Giá bán 2", "Giá bán 3", "Giá mua 1", "Giá mua 2", "Giá mua 3",
        //             "Giá mở cửa", "Giá cao nhất", "Giá thấp nhất", "Giá trung bình"]
        // const buySellHeaders = ["KL mua 1", "KL mua 2", "KL mua 3", "KL bán 1", "KL bán 2", "KL bán 3"] 
        var floorCeilRefer = await this.getFloorCeilReferValues();
        var buySellValues = [];
        var pricesValues = [];

        pricesValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.INNO_CHANGE_LATEST_PRICE));
        pricesValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.INNO_CHANGE_LATEST_DEVIATION));
        pricesValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.INNO_CHANGE_LATEST_PERCENT_DEV));
        pricesValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.GIA_BAN_1));
        pricesValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.GIA_BAN_2));
        pricesValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.GIA_BAN_3));
        pricesValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.GIA_MUA_1));
        pricesValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.GIA_MUA_2));
        pricesValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.GIA_MUA_3));
        await pricesValues.push(['-', this.BASE_PAGE_FIXTURES.yellowColor, this.BASE_PAGE_FIXTURES.yellowColor]);
        pricesValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.MORE_INFO_HIGHEST_PRICE_IN_DAY));
        pricesValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.MORE_INFO_LOWEST_PRICE_IN_DAY));
        pricesValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.MORE_INFO_AVG_PRICE));


        buySellValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.KL_MUA_1));
        buySellValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.KL_MUA_2));
        buySellValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.KL_MUA_3));
        buySellValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.KL_BAN_1));
        buySellValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.KL_BAN_2));
        buySellValues.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.KL_BAN_3));

        return [floorCeilRefer, pricesValues, buySellValues];
    };

    async checkPriceColorOfTradeLog() {
        var failList = [];

        const floorCeilRefer = [];
        floorCeilRefer.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.MORE_INFO_FLOOR_PRICE));
        floorCeilRefer.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.MORE_INFO_CEIL_PRICE));
        floorCeilRefer.push(await this.utilsObject.getValueColorBgColor(this.page, this.EQUITY_FIXTURES.MORE_INFO_REFER_PRICE));

        const pricesData = this.page.$$eval(this.EQUITY_FIXTURES.tradeLogPrices, elements => {
            var listData = [];
            // start to check from 1, because 0 is the header
            for (var i = 1; i < elements.length; i++) {
                listData.push([elements[i].textContent, window.getComputedStyle(elements[i]).color]);
            }
            return listData;
        });


        for (var i = 0; i < pricesData.length; i++) {
            let sValue = pricesData[i][0];
            let actualColor = pricesData[i][1];
            var expectedColor = await this.getExpectedColor(floorCeilRefer[0], floorCeilRefer[1], floorCeilRefer[2], sValue)
            if (actualColor != expectedColor) {
                console.log('worong trade log')
                failList.push(`Trade log, price ${sValue} is wrong color. Actual: ${actualColor}, expected: ${expectedColor}`);
            }
        }
        return failList;
    };

    async checkTypeTradeColorOfTradeLog() {
        var failList = [];
        const typesData = this.page.$$eval(this.EQUITY_FIXTURES.tradeLogTypes, elements => {
            var listData = [];
            // start to check from 1, because 0 is the header
            for (var i = 1; i < elements.length; i++) {
                listData.push([elements[i].textContent, window.getComputedStyle(elements[i]).color]);
            }
            return listData;
        });

        for (var i = 0; i < typesData.length; i++) {
            let sValue = typesData[i][0];
            let actualColor = typesData[i][1];
            let expectedColor = 'NOT_FOUND';
            if (sValue == '') {
                continue;
            } else if (sValue == 'M') {
                expectedColor = this.EQUITY_FIXTURES.greenColor;
            } else if (sValue == 'B') {
                expectedColor = this.EQUITY_FIXTURES.redColor;
            }

            if (actualColor != expectedColor) {
                failList.push(`${sValue} is wrong color. Actual: ${actualColor}, expected: ${expectedColor}`);
            }
        }
        return failList;
    };

    async selectPriceBoardAtStockCode(stockCode) {
        var cellLocator = this.EQUITY_FIXTURES.priceBoardRowIdxColumnName
            .replace('%stock_code', stockCode)
            .replace('%column_name', this.EQUITY_FIXTURES.priceBoardLastPriceCol);
        await this.utilsObject.clickToElement(this.page, cellLocator);
        await this.sleep(1);
    };

}