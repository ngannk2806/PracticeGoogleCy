const TEST_DATA_FILE = require('../fixtures/trading/data-test/tfe_equity_debug.json');
const Equity = require('./equity');


const runTheTest = async () => {
    const url = await equity.launchBrowser();
    var equity = new Equity();
    const title = await equity.getTitle();
    await expect(url).toContain('/login');
    await expect(title).toEqual('myhsc - Dịch vụ');
    const homeUrl = await equity.login(TEST_DATA_FILE.userName, TEST_DATA_FILE.password);
    await expect(homeUrl).toContain('/FO_TF_SQ/MOV');
    await equity.clickEquityButton();

}

test('testing login function', async () => {
    const NUMBER_OF_RUNS = 2;
    const testRuns = []
    for (let index = 0; index < NUMBER_OF_RUNS; index++) {
        testRuns.push(runTheTest())
    }
    return Promise.all(testRuns);
})