const pt = require('puppeteer');
const TEST_DATA_FILE = require('../fixtures/trading/data-test/tfe_equity_etf.json');
const it = require('jest-retries');
const EquityMarket = require('./market_equity');
const utils = require('./utils');

jest.setTimeout(120 * 1000);

describe('Checking Equity Market', () => {


    var equity = new EquityMarket();
    var utilsObject = new utils();


    beforeAll(async () => {
        const url = await equity.launchBrowser();
        const title = await equity.getTitle();
        await expect(url).toContain('/login');
        await expect(title).toEqual('myhsc - Dịch vụ');
        const homeUrl = await equity.login(TEST_DATA_FILE.userName, TEST_DATA_FILE.password);
        await equity.gotoEquityMarket();
    });

    afterAll(async () => {
        await equity.clickCloseBtnIfAny();

        await equity.logOut();
        await equity.closeBrowser();
    });

    beforeEach(async () => {
        await equity.reLoginIfAnyAndGoToEquity();

        const curUrl = await equity.getCurrentUrl();
        if (!curUrl.includes('/FO_TF_SQ')) {
            await equity.gotoEquityMarket();
        };
    });

    afterEach(async () => {
        await equity.clickConfirmButtonIfAny();
    });


    TEST_DATA_FILE.stockCodes.forEach((code, index, lists) => {
        if (index >= 0) {
            it(`search ${code} then freeze browser`, async () => {

                await equity.selectOneStockView();

                const actualCode = await equity.searchStockCode(code, 1);
                await expect(actualCode).toMatch(code);
                await equity.sleep(1);

                await equity.setPageIntercept();
            });

            it(`with ${code} then check colors`, async () => {
                const priceHeaders = ["Giá khớp", "Thay đổi giá", "% thay đổi giá", "Giá bán 1", "Giá bán 2", "Giá bán 3", "Giá mua 1", "Giá mua 2", "Giá mua 3",
                    "Giá mở cửa", "Giá cao nhất", "Giá thấp nhất", "Giá trung bình"]
                const buySellHeaders = ["KL mua 1", "KL mua 2", "KL mua 3", "KL bán 1", "KL bán 2", "KL bán 3"]

                const allPricesValues = await equity.getPricesValues();
                const floorCeilRefer = allPricesValues[0];
                const pricesToCheck = allPricesValues[1];
                const buySellValues = allPricesValues[2];
                const failListFloorCeilRefer = await equity.checkFloorCeilRefeColors(floorCeilRefer[0], floorCeilRefer[1], floorCeilRefer[2]);
                const failListBuySell = await equity.checkBuySellNumbersColors(buySellHeaders, buySellValues);
                const failListPrices = await equity.checkPricesColors(floorCeilRefer[0], floorCeilRefer[1], floorCeilRefer[2], priceHeaders, pricesToCheck);
                const failSameColorLastDeviationPercent = await equity.checkLatestDevPercent(pricesToCheck[0], pricesToCheck[1], pricesToCheck[2]);


                if (failListPrices.length > 0 || failListBuySell.length > 0 || failListFloorCeilRefer.length > 0 || failSameColorLastDeviationPercent.length > 0) {
                    await equity.page.screenshot({ path: `logs/equity_market_${code}.png` });
                }
                await utilsObject.writeFailCheckColorToFile(code, floorCeilRefer,
                                                            failListFloorCeilRefer, failListBuySell, failListPrices, failSameColorLastDeviationPercent,
                                                            buySellValues, buySellHeaders, pricesToCheck, priceHeaders,
                                                            'equity_market_');


                // await console.log(`floorCeilRefer: ${floorCeilRefer.join('\n')}`);
                // await console.log(`pricesToCheck: ${pricesToCheck.join('\n')}`);
                // await console.log(`buySellValues: ${buySellValues.join('\n')}`);

                //assertion
                await expect(failListFloorCeilRefer.length).toBe(0);
                await expect(failListBuySell.length).toBe(0);
                await expect(failListPrices.length).toBe(0);

            });

            it(`with ${code} then check color of trade log`, async () => {
                var priceFailList = await equity.checkPriceColorOfTradeLog();
                var typeFailList = await equity.checkTypeTradeColorOfTradeLog();

                await expect(priceFailList.length).toBe(0);
                await expect(typeFailList.length).toBe(0)
                if (priceFailList.length > 0) {
                    await utilsObject.writeFailListToFile(code, priceFailList, 'equity_market_');
                }
                if (typeFailList.length > 0) {
                    await utilsObject.writeFailListToFile(code, typeFailList, 'equity_market_')
                }
            })

            it(`with ${code} then stop freeze browser`, async () => {
                await equity.removePageIntercept();
            });
        }

    });

})