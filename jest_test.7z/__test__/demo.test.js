const pt = require('puppeteer');
const TEST_DATA_FILE = require('../fixtures/trading/data-test/tfe_equity_etf.json');
const it = require('jest-retries');
const EquityMarket = require('./market_equity');
const utils = require('./utils');

jest.setTimeout(120 * 1000);

describe('Test demo', () => {

    var equity = new EquityMarket();
    var utilsObject = new utils();


    beforeAll(async () => {
        const url = await equity.launchBrowser();
        const title = await equity.getTitle();
        await expect(url).toContain('/login');
        await expect(title).toEqual('myhsc - Dịch vụ');
        const homeUrl = await equity.login(TEST_DATA_FILE.userName, TEST_DATA_FILE.password);
        await equity.gotoEquityMarket();
    });

    afterAll(async () => {
        equity.closeBrowser();
    });



    it(`Demo test 2`, async () => {
        var total = 0;
        var max = 10;
        var retries = 3;
        var failStocks = [];
        //capturing websocket data
        const clientCDP = await equity.page.target().createCDPSession();
        await clientCDP.send('Network.enable');
        await clientCDP.send('Page.enable');

        var isPassed = clientCDP.on('Network.webSocketFrameReceived', async ({ requestId, timestamp, response }) => {
            console.log(`Network.webSocketFrameReceived, requestId xxxxxx : ${requestId}, timestamp: ${timestamp} - ${recievedTime}, \nresponse.payloadData: ${stringData}`);
            if (response.payloadData.includes("UpdateStockMsg")
                && total <= max) {
                total = total + 1;
                var recievedTime = new Date(timestamp * 1000000).toLocaleTimeString("en-US");
                var stringData = response.payloadData.substring(0, response.payloadData.length - 1).trim();
                console.log(`Network.webSocketFrameReceived, requestId: ${requestId}, timestamp: ${timestamp} - ${recievedTime}, \nresponse.payloadData: ${stringData}`);
                var wsJSData = stringData.split('|');
                if (wsJSData.length > 0) {
                    console.log(`Checking ${wsJSData[0]} .........`);
                    //capturing value of HTML element
                    //get stockCode from WS data
                    const stockCode = wsJSData[0].substring(wsJSData[0].length - 3, wsJSData[0].length);
                    var i = retries;
                    for (var i = retries; i > 0; i--) {
                        console.log(`Checking ${stockCode} with retry ${i}.....`);
                        const newVal = utilsObject.getTextOfElement(equity.page, `(//div[@row-id="${stockCode}"]//*[@col-id="LastPriceCol"])//*[not(*)]`);
                        console.log(`${stockCode} at retry ${i}, displayed value: ${newVal}`);
                        console.log(`${stockCode} is displayed.....`);
                        if (wsJSData[1] == newVal) {
                            i = 0;
                            isPassed = true;
                            console.log(`${stockCode} is displayed.....`);
                        }
                        equity.sleep(1 / 2);
                    };
                };
                failStocks.push(stockCode);
            };

        });


        await expect(isPassed).toEqual(true);
    });

})