const fs = require("fs");

module.exports = class Utils {
  timerLogin(callback) {
    console.log('Ready....go!');
    setTimeout(() => {
      console.log("Time's up -- stop!");
      callback && callback();
    }, 60 * 1000);

  };

  getData(file) {
    return new Promise((resolve, reject) => {
      fs.readFile(file, (err, data) => {
        if (err) return reject(err);
        try {
          const json = JSON.parse(data);
          resolve(json);
        } catch (E) {
          reject(E);
        }
      })
    })
  };

  async getValueOfElement(page, xPath) {
    let [ele] = await page.$x(xPath);
    return await page.evaluate((ele) => {
      return ele.value;
    }, ele);
  }

  async scollToElement(page, xpath) {
    let [ele] = await page.$x(xpath);

    return await page.evaluate((ele) => {
      return ele.textContent;
    }, ele);
  };

  async getTextOfElement(page, xpath) {
    let [ele] = await page.$x(xpath);
    return await page.evaluate((ele) => {
      return ele.textContent;
    }, ele);
  };

  async getTextOfSpan(page, xpath) {
    let [ele] = await page.$x(xpath);
    return await page.evaluate((ele) => {
      return ele.innerText;
    }, ele);
  };

  async clickToElement(page, xpath) {
    let [ele] = await page.$x(xpath);
    await ele.click();
  }

  async doubleClickToElement(page, xpath) {
    let [ele] = await page.$x(xpath);
    await ele.click(2);
  }

  async getValueColorBgColor(page, locator) {
    let [ele] = await page.$x(locator);
    return await page.evaluate((ele) => {
      var values = [];
      values.push(ele.textContent);
      values.push(window.getComputedStyle(ele).color);
      values.push(window.getComputedStyle(ele).backgroundColor);
      return values;
    }, ele);
  };

  async getSizeOfElement(page, xpath) {
    let elements = await page.$x(xpath);
    return elements.length;
  };


  async writeFailCheckColorToFile(code, floorCeilRefer, failListFloorCeilRefer, failListBuySell, failListPrices, failSameColorLastDeviationPercent,
    buySellValues, buySellHeaders, priceValues, priceHeaders, prefix='') {
    if (failListPrices.length > 0 || failListBuySell.length > 0 || failListFloorCeilRefer.length > 0 || failSameColorLastDeviationPercent.length > 0) {
      fs.appendFile(`logs/${prefix}log.txt`, `\n\n${code} is wrong\n`, 'utf8', (err) => { if (err) throw err; });
      fs.appendFile(`logs/${prefix}${code}.txt`, `floor: ${floorCeilRefer[0]}\n`, 'utf8', (err) => { if (err) throw err; });
      fs.appendFile(`logs/${prefix}${code}.txt`, `ceil: ${floorCeilRefer[1]}\n`, 'utf8', (err) => { if (err) throw err; });
      fs.appendFile(`logs/${prefix}${code}.txt`, `refer: ${floorCeilRefer[2]}\n`, 'utf8', (err) => { if (err) throw err; });
      fs.appendFile(`logs/${prefix}${code}.txt`, `${buySellHeaders}\n${buySellValues.join(';')}\n`, 'utf8', (err) => { if (err) throw err; });
      fs.appendFile(`logs/${prefix}${code}.txt`, `${priceHeaders}\n${priceValues.join(';')}\n`, 'utf8', (err) => { if (err) throw err; });
    }

    if (failListFloorCeilRefer.length > 0) {
      fs.appendFile(`logs/${prefix}log.txt`, `\nWrong floor/ ceil/ refer\n${failListFloorCeilRefer.join('\n')}`, 'utf8', (err) => { if (err) throw err; });
    }
    if (failListBuySell.length > 0) {
      fs.appendFile(`logs/${prefix}log.txt`, `\nWrong buy/ sell\n${failListBuySell.join('\n')}`, 'utf8', (err) => { if (err) throw err; });
    }
    if (failListPrices.length > 0) {

      fs.appendFile(`logs/${prefix}log.txt`, `\nWrong price\n${failListPrices.join('\n')}`, 'utf8', (err) => { if (err) throw err; });
    }
    if (failSameColorLastDeviationPercent.length > 0) {
      fs.appendFile(`logs/${prefix}log.txt`, `\nWrong colors are not same\n${failSameColorLastDeviationPercent.join('\n')}`, 'utf8', (err) => { if (err) throw err; });
    }
  };

  async writeFailListToFile(code, failList, prefix='') {
    fs.appendFile(`logs/${prefix}${code}.txt`, `${code}\n${failList.join(';')}\n`, 'utf8', (err) => { if (err) throw err; });
  };

  async writeFailListToLogFile(code, failList, prefix='') {
    fs.appendFile(`logs/${prefix}log.txt`, `\n\n${prefix} ${code} is wrong.\nWrong colors\n${failList.join('\n')}`, 'utf8', (err) => { if (err) throw err; })
  };

  async writeMsgToLogFile(msg, prefix='') {
    fs.appendFile(`logs/${prefix}log.txt`, `\n\n${prefix} ${msg}\n`, 'utf8', (err) => { if (err) throw err; })
  };


  getValueColors(element, window) {
    var values = [];
    values.push(element.textContent);
    values.push(window.getComputedStyle(element).color);
    values.push(window.getComputedStyle(element).backgroundColor);

    return values;
  };




}